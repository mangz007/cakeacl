<?php 
phpinfo();
